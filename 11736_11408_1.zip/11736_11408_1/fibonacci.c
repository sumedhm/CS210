#include <stdio.h>

long long int Iterative(long long int n)		//Uses iterative algorithm(Algorithm 1).
{
     long long int a=0,f=1,temp=0,i=3;			//f stores fibonacci number.
     if (n==0) return 0;
     else if (n==1) return 1;
     else for (i=2;i<=n;i++)
     {
         temp=f;
         f=a+f;
         a=temp;
         }
         return f;
}

long long int Recursive(long long int n)		//Uses recursive algorithm.(Algorithm 2)
{
     if (n==0) return 0;
     else if (n==1 || n==2) return 1;
     else return (Recursive(n-1)+Recursive(n-2));
}

long long int fibonacci(long long int n)		//Uses matrix multiplication method to find fibbonacci numbers.
{
     long long int i=2,a11=1,a12=1,a21=1,a22=0,b11=1,b12=1,b21=1,b22=0;
	while(i<n)					//Multiplying two matrices directly.
	{
		b11=a11+a12;				//multiplying to get next exponent of (1 1/1 0) matrix.
		b12=a11;
		b21=a21+a22;
		b22=a21;
		a11=b11;
		a12=b12;
		a21=b21;
		a22=b22;
		i++;					//from 2 to n-1.
	}
	return a11;					//F(n)= (a11*1)+(a12*0)=a11.
}

long long int Matrix(long long int n)			//Algorithm 3.(Matrix multiplication).
{
     if (n==0) return 0;
     else if (n==1 || n==2) return 1;
     else return fibonacci(n);
}

int main()						//Main function
{
         int type;					//Type of algorithm.
         long long int n,m,F_n;				//F(n)= F_n.
	 printf("\n\tThis program outputs F(n) mod m where F(n) is nth fibonacci number using three different algorithms to find F(n) on the choice of user");
         printf("\nEnter the code for type of algorithm to be used\n1 for iterative\n2 for recursive\n3 for using matrix method\n\t--\t");
         scanf("%d",&type);
 	 if (type==1) printf("\n\n\t\tUSING ITERATIVE ALGORITHM");
         if (type==2) printf("\n\n\t\tUSING RECURSIVE ALGORITHM");
         if (type==3) printf("\n\n\t\tUSING MATRIX ALGORITHM");

         printf("\n\n\tEnter the number n\t-\t");		//No.whose F(n) has to be calculated.
         scanf("%lld", &n);
         printf("\n\tEnter the number m\t-\t");
         scanf("%lld", &m);
         if (type==1) F_n=Iterative(n);
         if (type==2) F_n=Recursive(n);
         if (type==3) F_n=Matrix(n);
         {
                     printf("\nF(n) mod m for the entered values of n & m is %lld\nF(n)=%lld\n", F_n%m,F_n);
         }						//Print answer.
}
