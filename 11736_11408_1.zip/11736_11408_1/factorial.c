#include<stdio.h>              

main()
{
	int n,i,j,c=0;					// Variables(c for carry,m for no.of digits in factorial.)
	int f[100000],m=1;				//Array to store digits of factorial.
	f[0]=1;						//Initializing factorial to 1.
	printf("\nEnter the value of n: ");
	scanf(" %d",&n);
	for(i=2;i<=n;i++)
 	{
  		for(j=0;j<m;j++)			//Multiplying next number with all the digits in the factorial. 
		{
			f[j]=(i*f[j])+c;		//Calculating factorial.
			c=(f[j]/10);			//carry(storing one digit in one array,rest is carry)
			f[j]=(f[j]%10);
		}
  		while(c != 0) 
		{
			f[j]=(c%10);
			c=c/10;m++;j++;
		}
 	}
	if(n<0) printf("\nFactorial doesn't exist!!");	//Check for correct input.
	else
	{
		printf("The value of factorial:  ");	//printing factorial.
     		for(j=(m-1);j >= 0;j--) 
		{
			 printf("%d",f[j]);
		}
	}
	
	printf("\n\n");
}
